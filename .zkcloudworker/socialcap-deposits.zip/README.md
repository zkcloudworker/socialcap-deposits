# socialcap-deposits

Submitting deposits (credential fee payments) to the Socialcap account.

The worker will create an unsigned serialized transaction that will later 
be signed and sent using Auro wallet.

## Installation

You need to install `node (v20+)` and `git` and clone this repo

```
git clone https://github.com/zkcloudworker/socialcap-deposits
cd socialcap-deposits
```

## Deploy

Install zkCloudWorker CLI tool
```sh
npm install -g zkcloudworker-cli
```

Deploy this repo to zkCloudWorker cloud. 
```sh
zkcw deploy
```

or, in verbose mode
```sh
zkcw deploy -v
```

## Run worker

Run:
```sh
yarn start payer_address fee amount
```

## Using the zkCloudWorker API 

Look the `src/execute.ts` example code.

#### 1. Get the JWT API token

Use this [Telegram bot](https://t.me/minanft_bot?start=auth) to get your API token.

### 2. Connect the API client
```
  import "dotenv/config";
  import { zkCloudWorkerClient } from "zkcloudworker";

  // see the '.env-example'
  const JWT = process.env.JWT;

  const api = new zkCloudWorkerClient({
    jwt: JWT,
  });
```

### 3. Start the worker
```
  const response = await api.execute({
    mode: "async",
    repo: "socialcap-deposits",
    developer: "MAZ", // keep it simple, no strange chars here ! 
    task: "create-unsigned-transaction",
    metadata: `Payment for Claim ...`,
    args: JSON.stringify({ 
      chainId: 'devnet' 
    }),
    transactions: [JSON.stringify({
      memo: `Claim ...`.substring(0, 32), // memo field in Txn limited to 32 chars
      payer: 'B62q...oU',
      fee: 2,
      amount: 2
    })],
  });

  console.log("API response:", response);
  const jobId = response?.jobId;
  if (jobId === undefined) {
    throw new Error("Job ID is undefined");
  }
```

Params to API.execute():

  - `mode`:
  - `repo`: 
  - `task`:  

    mode: "async",
    repo: "socialcap-deposits",
    developer: "MAZ", // keep it simple, no strange chars here ! 
    task: "create-unsigned-transaction",
    metadata: `Payment for Claim ...`,
    args: JSON.stringify({ 
      chainId: 'devnet' 
    }),
    transactions: [JSON.stringify({
      memo: `Claim ...`.substring(0, 32), // memo field in Txn limited to 32 chars
      payer: 'B62q...oU',
      fee: 2,
      amount: 2
    })],



#### 4. Wait for the Job to finish

```
  console.log("API response:", response);
  const jobId = response?.jobId;
  if (jobId === undefined) {
    throw new Error("Job ID is undefined");
  }

  console.log("Waiting for job ...");
  const result = await api.waitForJobResult({ jobId });
  console.log("Job result:", result);
}


