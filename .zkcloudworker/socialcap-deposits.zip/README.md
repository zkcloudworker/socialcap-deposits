# socialcap-deposits
Submitting deposits (credential fee payments) to the Socialcap account.
